require('./bootstrap');

import Apline from 'alpinejs';

window.Apline = Apline;

Apline.start();
