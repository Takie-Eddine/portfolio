<li>
    <a href="{{$href}}" class="text-xs font-medium text-dark py-2 flex hover:text-primary dark:text-gray-200 lg:inline-flex lg:ml-6 xl:ml-12">
        {{$slot}}
    </a>
</li>
