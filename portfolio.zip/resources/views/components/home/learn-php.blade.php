<x-call-to-action>
    @slot('title')
            <h4 class="text-white text-base font-semibold mb-2">
        </h4>
        <h2 class=" text-white font-bold text-3xl sm:text-[38px] leading-tight mb-6 sm:mb-8 lg:mb-0 ">
            <br class="hidden xs:block"/>
        </h2>
        @endslot

</x-call-to-action>
