<x-app-layout>
    <x-home.hero></x-home.hero>
    <x-home.learn-php></x-home.learn-php>
    <x-home.portfolio></x-home.portfolio>
    <x-home.about></x-home.about>
    <x-home.contact></x-home.contact>
</x-app-layout>
