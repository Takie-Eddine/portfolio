<li>
    <a href="<?php echo e($href); ?>" class="text-xs font-medium text-dark py-2 flex hover:text-primary dark:text-gray-200 lg:inline-flex lg:ml-6 xl:ml-12">
        <?php echo e($slot); ?>

    </a>
</li>
<?php /**PATH C:\wamp64\www\portfolio\resources\views/layout/navbar-item.blade.php ENDPATH**/ ?>