<section id="about" class="dark:bg-slate-800 pt-20 lg:pt-[120px] pb-12 lg:pb-[90px] overflow-hidden">
    <div class="container">
        <div class="flex flex-wrap justify-between items-center -mx-4">
            <div class="w-full lg:w-6/12 px-4">
                <div class="flex items-center -mx-3 sm:-mx-4">
                    <div class="w-full xl:w-1/2 px-3 sm:px-4">
                        <div class="py-3 sm:py-4">
                            <img src="<?php echo e(url('/img/avatar.jpeg')); ?>" alt=""  class="rounded-2xl w-full">
                        </div>
                        <div>
                            <img src="<?php echo e(url('/img/avatar.jpeg')); ?>" alt=""  class="rounded-2xl w-full">
                        </div>
                    </div>
                    <div class="w-full xl:w-1/2 px-3 sm:px-4">
                        <div class="my-4 relative z-10">
                            <img src="<?php echo e(url('/img/avatar.jpeg')); ?>" alt="" class="rounded-2xl w-full">
                            <?php if (isset($component)) { $__componentOriginal9f4ac1046ae39bdc6dfc17afba750507010299e3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AboutDots::class, []); ?>
<?php $component->withName('about-dots'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f4ac1046ae39bdc6dfc17afba750507010299e3)): ?>
<?php $component = $__componentOriginal9f4ac1046ae39bdc6dfc17afba750507010299e3; ?>
<?php unset($__componentOriginal9f4ac1046ae39bdc6dfc17afba750507010299e3); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="w-full lg:w-1/2 xl:w-5/12 px-4">
                <div class="mt-10 lg:mt-0">
                    <span class="font-semibold text-lg text-primary mb-2 block">
                        <blockquote class="text-sm text-gray-500 italic py-2 px-3 border-l-4 border-amber-500">
                            "Everything is achievable with hard work"
                        </blockquote>
                    </span>
                    <h2 class="font-bold text-3xl sm:text-4xl dark:text-gray-200 mb-8">
                        About Me
                    </h2>
                    <p>
                        I have been working as a professional software developer for 2+ years. <br />
                        During my career I have worked on various types of projects with various technologies,
                        but very often I feel that I am a junior developer who just started coding now. <br />
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\wamp64\www\portfolio\resources\views/components/home/about.blade.php ENDPATH**/ ?>