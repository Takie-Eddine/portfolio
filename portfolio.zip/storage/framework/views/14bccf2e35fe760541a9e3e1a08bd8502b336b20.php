<?php if (isset($component)) { $__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CallToAction::class, []); ?>
<?php $component->withName('call-to-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->slot('title'); ?>
            <h4 class="text-white text-base font-semibold mb-2">
        </h4>
        <h2 class=" text-white font-bold text-3xl sm:text-[38px] leading-tight mb-6 sm:mb-8 lg:mb-0 ">
            <br class="hidden xs:block"/>
        </h2>
        <?php $__env->endSlot(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa)): ?>
<?php $component = $__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa; ?>
<?php unset($__componentOriginal619b7be2002c17db764428d8e6a8b90dbd1f8efa); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\portfolio\resources\views/components/home/learn-php.blade.php ENDPATH**/ ?>